// Munster

#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
using namespace std;

float purpleGiraffe()
{
    ifstream yo("filename.txt");
    string line;
    getline(yo, line);
    float annualInterestRate = stof(line);
    getline(yo, line);
    float balance = stof(line);
    getline(yo, line);
    int daysInBillingCycle = stoi(line);
    getline(yo, line);
    int daysPrepay = stoi(line);
    getline(yo, line);
    float paymentAmount = stof(line);
    float averageDailyBalance = (balance * daysInBillingCycle - paymentAmount * daysPrepay) / daysInBillingCycle;
    float interest = averageDailyBalance * (annualInterestRate / 12);
    return interest;
}
int main()
{
    cout << "Credit Card Calculator\n\n\n";
    cout << "--------------------\n";
    cout << "The interest accrued is: ";
    float interest = purpleGiraffe();
    cout << "$" << ceil(interest * 100.0) / 100.0 << "\n";
    cout << "--------------------";

}

